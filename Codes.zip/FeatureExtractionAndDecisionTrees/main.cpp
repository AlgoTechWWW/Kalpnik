#include <opencv2/opencv.hpp>

#include "FeatureComputer.hpp"
#include "Classifier.h"
#include "LcBasic.h"
#include "HandDetector.hpp"

using namespace std;
using namespace cv;

int main (int argc, char * const argv[]) 
{
	bool TRAIN_MODEL = 1;
	bool TEST_MODEL = 1;
	
	if(TRAIN_MODEL)
	{
		string root = "EDSH/";
		string basename = "Handn3"; // Video Name
		string vid_filename		= root + "vid/"		+ basename + ".mp4";
		string msk_prefix		= root + "mask/"	+ basename + "/";
		string model_prefix		= root + "models/"	+ basename + "/";
		string globfeat_prefix  = root + "globfeat/"+ basename + "/";
		//string feature_set = "rvl";
		string feature_set = "l";
		
		HandDetector hd;
		hd.loadMaskFilenames(msk_prefix);
		hd.trainModels(basename, vid_filename, msk_prefix,model_prefix,globfeat_prefix,feature_set);
	}
	
	if(TEST_MODEL)
	{
		string root = "EDSH/";
		string basename = "EDSH1";
		string vid_filename		= root + "vid/"		+ basename + ".mp4";
		string model_prefix		= root + "models/"	+ basename + "/";
		string globfeat_prefix  = root + "globfeat/"+ basename + "/";
		string feature_set = "rvl";
		
		int num_models_to_average = 10;
		
		HandDetector hd;
		hd.testInitialize(model_prefix,globfeat_prefix,feature_set,num_models_to_average);

		VideoCapture cap(vid_filename);
		Mat im;
		Mat ppr;
		
		while(1)
		{
			cap >> im; if(!im.data) break;
			cap >> im; if(!im.data) break;
			resize(im,im,Size(640,360));
			hd.test(im,num_models_to_average);
			resize(hd._ppr,ppr,im.size(),0,0,INTER_LINEAR);
			addWeighted(im,0.7,ppr,0.3,0,ppr);
			imshow("result:contour",ppr);
			imshow("result:probability",hd._blu);
			waitKey(1);

		}
	}
	
}