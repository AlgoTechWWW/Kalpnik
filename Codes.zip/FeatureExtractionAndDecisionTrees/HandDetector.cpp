/*
 *  HandDetector.cpp
 *  TrainHandModels
 *
 *  Created by Kris Kitani on 4/1/13.
 *  Copyright 2013 __MyCompanyName__. All rights reserved.
 *
 */

#include "HandDetector.hpp"
#include <opencv2\highgui.hpp>

#define NUMBER_OF_CLASSES 2;

void HandDetector::loadMaskFilenames(string msk_prefix)
{
	string cmd = "cd " + msk_prefix + " > maskfilename.txt";
	system(cmd.c_str());
	
	ifstream fs;
	fs.open("maskfilename.txt");
	string val;
	while(fs>>val) _filenames.push_back(val);
}


void HandDetector::trainModels(string basename, string vid_filename,string msk_prefix,string model_prefix,string globfeat_prefix, string feature_set)
{
	cout << "HandDetector::trainModels()" << endl;
	
	stringstream ss;
	
	LcFeatureExtractor	_extractor;
	LcRandomTreesR		_classifier;
	
	_feature_set = feature_set;
	_extractor.set_extractor(feature_set);
	
	 VideoCapture cap(vid_filename);
	 if(!cap.isOpened())  // check if we succeeded
	 {
		printf("error opening file ");
	 }
        
	Mat color_img;
	
	int f = -1;
	int k = 0;
	
	while(1)
	{
		f++;
		
		//////////////////////////////////////////
		//										//
		//		 LOAD IMAGE AND MASK			//
		//										//
		//////////////////////////////////////////
		
		
		//cap >> color_img;
		//imwrite("hand1_img.jpg", color_img);
		if(f == 0)
		{
			for (int idx = 0; idx < 1; idx++)
			{
				cap >> color_img;			
			}
		}

		if(!color_img.data) break;
		resize(color_img,color_img,Size(640,360));
		imshow("src",color_img);
		moveWindow("src", 100, 500);
		waitKey(1);
		
		
		ss.str("");
		ss << msk_prefix + "mask" << f << ".jpg";
		Mat mask_img, hsv;
		//cvtColor(color_img, hsv, CV_BGR2HSV);
		//inRange(hsv, Scalar(0, 20, 150), Scalar(20, 80, 255), mask_img);
		//mask_img = color_img;
		//cvtColor(color_img, mask_img, CV_BGR2GRAY);		
		hsv = imread("S2G1.bmp", CV_LOAD_IMAGE_COLOR);
		cvtColor(hsv, mask_img, CV_BGR2GRAY);
		if(!mask_img.data) continue;
		else cout << "\n  Loading: " << ss.str() << endl;
		resize(mask_img,mask_img,Size(640,360));
		imshow("maskimg", mask_img);
		
		Mat dsp;
		cvtColor(mask_img,dsp,CV_GRAY2BGR);
		addWeighted(dsp,0.5,color_img,0.5,0,dsp);
		//imshow("src1",dsp);
		waitKey(1);
		
		
		
		//////////////////////////////////////////
		//										//
		//		 EXTRACT/SAVE HISTOGRAM			//
		//										//
		//////////////////////////////////////////
		
		Mat globfeat;
		computeColorHist_HSV(color_img,globfeat);
		
		ss.str("");
		ss << globfeat_prefix << "hsv_histogram_" << k << ".xml";
		cout << "  Writing global feature: " << ss.str() << endl;
		
		FileStorage fs;
		fs.open(ss.str(),FileStorage::WRITE);
		fs << "globfeat" << globfeat;
		fs.release();
		
		
		//////////////////////////////////////////
		//										//
		//		  TRAIN/SAVE CLASSIFIER			//
		//										//
		//////////////////////////////////////////
			
		/*Mat desc = Mat(50000, 225, CV_32FC1);
		Mat lab = Mat(50000,1, CV_32FC1);*/
		Mat desc, lab;
		/*Mat desc1, desc2, desc;
		Mat lab1, lab2, lab;*/
		vector<KeyPoint> kp;
		//kp = NULL;
		//desc = Mat(9, 2500, CV_32FC1);
		//lab = Mat(50, 1, CV_32FC1);
		mask_img.convertTo(mask_img,CV_8UC1);
		//_extractor.work(color_img, desc, mask_img, lab,1, NULL);/// feature extraction code //sai 
		
		
		
		//cv::FileStorage fsRead("Keypoints_hand2_frm_diffMask.yml", FileStorage::READ );
		cv::FileStorage fsRead("Keypoints_S2G1_frm_L.yml", FileStorage::READ );
		fsRead["Descriptors"] >>  desc;
		fsRead["labels"] >> lab;
		fsRead.release();
		imwrite("desc.bmp", desc);
		imwrite("lab.bmp", lab);
		/*for (int idx = 0; idx < 50000; idx++)
		{
			desc.push_back(desc1.row(idx));
			lab.push_back(lab1.row(idx));
		}*/
		/*cv::FileStorage fsRead1("Keypoints_hand1_frm_diffMask.yml", FileStorage::READ );
		fsRead1["Descriptors"] >>  desc2;
		fsRead1["labels"] >> lab2;
		fsRead1.release();


		for (int idx = 0; idx < 50000; idx++)
		{
			desc.push_back(desc2.row(idx));
			lab.push_back(lab2.row(idx));
		}*/

		
		//_classifier.train(training_data,training_classifications);
		_classifier.train(desc, lab);
		
		ss.str("");
		ss << model_prefix << "model_" + basename + "_"+ feature_set + "_" << k;
		_classifier.save(ss.str());
		
		k++;
		
	}
	
}


void HandDetector::testInitialize(string model_prefix,string globfeat_prefix, string feature_set, int knn)
{
	
	stringstream ss;
	
	//////////////////////////////////////////
	//										//
	//		     FEATURE EXTRACTOR			//
	//										//
	//////////////////////////////////////////
	
	cout << "set extractor" << endl;
	_feature_set = feature_set;
	_extractor.set_extractor(_feature_set);
	
	
	//////////////////////////////////////////
	//										//
	//		       LOAD CLASSIFIERS			//
	//										//
	//////////////////////////////////////////
	
	{ // This will only work on linux systems
		string cmd;
		cmd = "find " + model_prefix + " -name *.xml -print > modelfilename.txt";
		cout << cmd << endl;
		system(cmd.c_str());
		
		ifstream fs;
		vector<string> filenames;
		fs.open("modelfilename.txt");
		filenames.clear();
		
		string val;
		while(fs>>val) filenames.push_back(val);
		
		int num_models = (int)filenames.size();
		
		cout << "Load class" << endl;
		_classifier = vector<LcRandomTreesR>(num_models);
		
		for(int i=0;i<num_models;i++)
		{
			_classifier[i].load_full(filenames[i]);
		}
	}
	
	
	//////////////////////////////////////////
	//										//
	//		       LOAD HISTOGRAM			//
	//										//
	//////////////////////////////////////////
	
	{
		string cmd;
		cmd = "find " + globfeat_prefix + " -name *.xml -print > globfeatfilename.txt";
		cout << cmd << endl;
		system(cmd.c_str());
		
		ifstream fs;
		vector<string> filenames;
		fs.open("globfeatfilename.txt");
		filenames.clear();
		
		string val;
		while(fs>>val) filenames.push_back(val);
		
		int num_models = (int)filenames.size();
		
		for(int i=0;i<num_models;i++)
		{
			Mat globalfeat;
			
			cout << filenames[i] << endl;
			FileStorage fs;
			fs.open(filenames[i],FileStorage::READ);
			fs["globfeat"] >> globalfeat;
			fs.release();
			
			_hist_all.push_back(globalfeat);
			
		}
	}
	
	if(_hist_all.rows != (int)_classifier.size()) cout << "ERROR: Number of classifers doesn't match number of global features.\n";
	
	//////////////////////////////////////////
	//										//
	//		       KNN CLASSIFIER			//
	//										//
	//////////////////////////////////////////
	
	cout << "Building FLANN search structure...";
	_indexParams = *new flann::KMeansIndexParams;	
	_searchtree  = *new flann::Index(_hist_all, _indexParams);
	_knn		= knn;						//number of nearest neighbors 
	_indices	= vector<int> (_knn); 
	_dists		= vector<float> (_knn);
	cout << "done." << endl;
		

}

void HandDetector::test(Mat &img)
{
	Mat tmp = Mat();
	test(img,tmp,1);
}

void HandDetector::test(Mat &img, Mat &dsp)
{
	test(img,dsp,1);
}

void HandDetector::test(Mat &img, int num_models)
{
	Mat tmp = Mat();
	test(img,tmp,num_models);
}


void HandDetector::test(Mat &img, Mat &dsp, int num_models)
{
	if(num_models>_knn) return;
	
	Mat hist;
	computeColorHist_HSV(img,hist);									// extract hist
	
	_searchtree.knnSearch(hist,
						   _indices, _dists, 
						   _knn, flann::SearchParams(4));			// probe search
	
	_extractor.work(img,_descriptors,3,&_kp);						// every 3rd pixel
	
	if(!_response_avg.data) _response_avg = Mat::zeros(_descriptors.rows,1,CV_32FC1); 
	else _response_avg *= 0;
	
	float norm = 0;
	for(int i=0;i<num_models;i++)
	{
		int idx = _indices[i];
		_classifier[idx].predict(_descriptors,_response_vec);		// run classifier
		
		_response_avg += _response_vec*float(pow(0.9f,(float)i));
		norm += float(pow(0.9f,(float)i));
	}
	
	_response_avg /= norm;
	
	_sz = img.size();
	_bs = _extractor.bound_setting;	
	rasterizeResVec(_response_img,_response_avg,_kp,_sz,_bs);		// class one
	
	colormap(_response_img,_raw,1);
	

	vector<Point2f> pt;
	_ppr = postprocess(_response_img,pt);
	colormap(_ppr,_ppr,1);
	
}


Mat HandDetector::postprocess(Mat &img,vector<Point2f> &pt)
{
	Mat tmp;
	
	GaussianBlur(img,tmp,cv::Size(11,11),0,0,BORDER_REFLECT);
	
	colormap(tmp,_blu,1);	// for visualization
	
	tmp = tmp > 0.04;
	
	vector<vector<cv::Point> > co;
	vector<Vec4i> hi;
	
	findContours(tmp,co,hi,CV_RETR_EXTERNAL,CV_CHAIN_APPROX_NONE);
	tmp *= 0;
	
	Moments m;
	//vector<Point2f> pt;
	for(int i=0;i<(int)co.size();i++)
	{
		if(contourArea(Mat(co[i])) < (tmp.rows*tmp.cols*0.01)) continue;
		drawContours(tmp, co,i, CV_RGB(255,255,255), CV_FILLED, CV_AA);
		m = moments(Mat(co[i]));
		pt.push_back(Point2f(m.m10/m.m00,m.m01/m.m00));
	}
	
	return tmp;

}


void HandDetector::rasterizeResVec(Mat &img, Mat&res,vector<KeyPoint> &keypts, cv::Size s, int bs)
{	
    if((img.rows!=s.height) || (img.cols!=s.width) || (img.type()!=CV_32FC1) ) img = Mat::zeros( s, CV_32FC1);
	
	for(int i = 0;i< (int)keypts.size();i++)
    {
		int r = floor(keypts[i].pt.y);
		int c = floor(keypts[i].pt.x);
		img.at<float>(r,c) = res.at<float>(i,0);
	}
}


void HandDetector::colormap(Mat &src, Mat &dst, int do_norm)
{
	
	double minVal,maxVal;
	minMaxLoc(src,&minVal,&maxVal,NULL,NULL);
	
	//cout << "colormap minmax: " << minVal << " " << maxVal << " Type:" <<  src.type() << endl;
	
	Mat im;
	src.copyTo(im);
	
	if(do_norm) im = (src-minVal)/(maxVal-minVal);		// normalization [0 to 1]
	
	Mat mask;	
	mask = Mat::ones(im.size(),CV_8UC1)*255.0;	
	
	compare(im,0.01,mask,CMP_GT);						// one color values greater than X	
	
	
	Mat U8;
	im.convertTo(U8,CV_8UC1,255,0);
	
	Mat I3[3],hsv;
	I3[0] = U8 * 0.85;
	I3[1] = mask;
	I3[2] = mask;
	merge(I3,3,hsv);
	cvtColor(hsv,dst,CV_HSV2RGB_FULL);
	
	
}


void HandDetector::computeColorHist_HSV(Mat &src, Mat &hist)
{
	
	int bins[] = {4,4,4};
    if(src.channels()!=3) exit(1);
    
	//Mat tmp;
    //src.copyTo(tmp);
    
	Mat hsv;
    cvtColor(src,hsv,CV_BGR2HSV_FULL);
    
	int histSize[] = {bins[0], bins[1], bins[2]};
    Mat his;
    his.create(3, histSize, CV_32F);
    his = Scalar(0);   
    CV_Assert(hsv.type() == CV_8UC3);
    MatConstIterator_<Vec3b> it = hsv.begin<Vec3b>();
    MatConstIterator_<Vec3b> it_end = hsv.end<Vec3b>();
    for( ; it != it_end; ++it )
    {
        const Vec3b& pix = *it;
        his.at<float>(pix[0]*bins[0]/256, pix[1]*bins[1]/256,pix[2]*bins[2]/256) += 1.f;
    }
	
    // ==== Remove small values ==== //
    float minProb = 0.01;
    minProb *= hsv.rows*hsv.cols;
    Mat plane;
    const Mat *_his = &his;
	
    NAryMatIterator itt = NAryMatIterator(&_his, &plane, 1);   
    threshold(itt.planes[0], itt.planes[0], minProb, 0, THRESH_TOZERO);
    double s = sum(itt.planes[0])[0];
	
    // ==== Normalize (L1) ==== //
    s = 1./s * 255.;
    itt.planes[0] *= s;
    itt.planes[0].copyTo(hist);
	
	
}

